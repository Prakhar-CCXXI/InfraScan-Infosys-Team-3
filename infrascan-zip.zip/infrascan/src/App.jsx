import {Routes,Route,Navigate} from 'react-router-dom'
import {Layout} from './ui.jsx'
import {Login,Register,Roles} from './pages/Auth.jsx'
import {Dashboard,CreateInspection,Upload,Results,InspectionHistory,DamageProgression} from './pages/Inspections.jsx'
import {Assets,AssetDetail,MapView} from './pages/Assets.jsx'
import {Maintenance,Reports,Analytics,Users,Profile,Notifications,Models,AuditLog} from './pages/Ops.jsx'
export default function App(){return <Routes>
 <Route path="/login" element={<Login/>}/><Route path="/register" element={<Register/>}/><Route path="/roles" element={<Roles/>}/>
 <Route element={<Layout/>}>
  <Route path="/dashboard" element={<Dashboard/>}/><Route path="/inspections/new" element={<CreateInspection/>}/>
  <Route path="/inspections/upload" element={<Upload/>}/><Route path="/inspections/results" element={<Results/>}/>
  <Route path="/inspections/history" element={<InspectionHistory/>}/><Route path="/inspections/progression" element={<DamageProgression/>}/>
  <Route path="/assets" element={<Assets/>}/><Route path="/assets/:id" element={<AssetDetail/>}/><Route path="/map" element={<MapView/>}/>
  <Route path="/maintenance" element={<Maintenance/>}/><Route path="/reports" element={<Reports/>}/><Route path="/analytics" element={<Analytics/>}/>
   <Route path="/users" element={<Users/>}/><Route path="/profile" element={<Profile/>}/>
   <Route path="/notifications" element={<Notifications/>}/><Route path="/models" element={<Models/>}/><Route path="/audit" element={<AuditLog/>}/>
  </Route>
 <Route path="*" element={<Navigate to="/login"/>}/></Routes>}
