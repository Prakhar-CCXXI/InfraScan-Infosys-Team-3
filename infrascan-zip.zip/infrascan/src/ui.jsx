import {useState} from 'react'
import {NavLink,Outlet,Navigate,useNavigate} from 'react-router-dom'
export const useStore=(k,init)=>{
 const [v,s]=useState(()=>{try{return JSON.parse(localStorage.getItem(k))??init}catch{return init}})
 return [v,x=>{s(x);localStorage.setItem(k,JSON.stringify(x))}]}
export const Badge=({t})=><span className={'b '+String(t).toLowerCase().replace(/ /g,'-')}>{t}</span>
export const Card=({title,right,children})=><div className="card"><div className="row"><h3>{title}</h3>{right}</div>{children}</div>
export const Stat=({label,value})=><div className="card stat"><span>{label}</span><b>{value}</b></div>
export const Field=({label,err,...p})=><label>{label}<input {...p}/>{err&&<div className="err">{err}</div>}</label>
export const Bars=({data,color='#2563eb'})=>{const m=Math.max(...data.map(d=>d[1]),1)
 return <svg viewBox={`0 0 ${data.length*60} 150`} width="100%" height="170">{data.map(([l,v],i)=>
 <g key={l}><rect x={i*60+10} y={120-v/m*100} width="40" height={v/m*100} rx="4" fill={color}/>
 <text x={i*60+30} y={115-v/m*100} fontSize="11" textAnchor="middle">{v}</text>
 <text x={i*60+30} y="140" fontSize="10" textAnchor="middle">{l}</text></g>)}</svg>}
export const downloadCSV=(name,rows)=>{if(!rows.length)return
 const h=Object.keys(rows[0]);const body=[h,...rows.map(r=>h.map(k=>`"${String(r[k]).replace(/"/g,'""')}"`))].join('\n')
 const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([body],{type:'text/csv'}));a.download=name;a.click()}
export const downloadJSON=(name,value)=>{const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([JSON.stringify(value,null,2)],{type:'application/json'}));a.download=name;a.click()}
export function Layout(){
 const [o,so]=useState(false);const nav=useNavigate()
 if(!localStorage.getItem('is_user'))return <Navigate to="/login"/>
 const u=JSON.parse(localStorage.getItem('is_user')||'{}')
 const role=u.role||''
 const L=[['dashboard','Dashboard'],['inspections/new','New Inspection'],['inspections/upload','Image Upload'],['inspections/results','Damage Analysis'],['inspections/history','Inspection History'],['inspections/progression','Damage Progression'],['assets','Infrastructure Assets'],['map','Damage Mapping'],['maintenance','Maintenance'],['reports','Reports'],['analytics','Analytics'],['notifications','Notifications'],['models','Model Management'],['users','User Management'],['audit','Audit Logs'],['profile','Profile']]
 const visible=L.filter(([p])=>!(p=='users'||p=='audit'||p=='models')||role=='Administrator'||(p=='models'&&role=='Civil Engineer')||(p=='audit'&&role=='Infrastructure Manager'))
 return <><aside className={'side'+(o?' open':'')} onClick={()=>so(false)}><h2>🏗 InfraScan</h2>
 {visible.map(([p,l])=><NavLink key={p} to={'/'+p}>{l}</NavLink>)}
 <button className="ghost" style={{marginTop:12}} onClick={()=>{localStorage.removeItem('is_user');nav('/login')}}>Logout</button></aside>
 <main className="main"><button className="menu ghost" onClick={()=>so(true)}>☰ Menu</button><Outlet/></main></>}
