import {useState} from 'react'
import {Link,useParams} from 'react-router-dom'
import {Badge,Card,Field,useStore} from '../ui.jsx'
import {assets,inspections} from '../data.js'
const col={High:'#dc2626',Moderate:'#f59e0b',Low:'#16a34a'}
export function Assets(){
 const [list,sl]=useStore('is_assets',assets),[q,sq]=useState(''),[t,st]=useState('All'),[show,ss]=useState(false),[f,sf]=useState({name:'',type:'Bridge',location:''}),[e,se]=useState('')
 const rows=list.filter(a=>(t=='All'||a.type==t)&&(a.name+a.location).toLowerCase().includes(q.toLowerCase()))
 const add=()=>{if(!f.name.trim()||!f.location.trim())return se('Name and location are required')
  sl([...list,{...f,id:'A'+Date.now(),status:'Active',severity:'Low',x:20+Math.random()*60,y:20+Math.random()*60}]);sf({name:'',type:'Bridge',location:''});se('');ss(false)}
 return <><div className="row"><h1>Infrastructure Assets</h1><button onClick={()=>ss(!show)}>+ Add Asset</button></div>
 {show&&<Card title="New asset"><Field label="Name" value={f.name} onChange={e=>sf({...f,name:e.target.value})}/>
 <label>Type<select value={f.type} onChange={e=>sf({...f,type:e.target.value})}>{['Bridge','Flyover','Dam','Tunnel','Road'].map(x=><option key={x}>{x}</option>)}</select></label>
 <Field label="Location" value={f.location} onChange={e=>sf({...f,location:e.target.value})}/>{e&&<div className="err">{e}</div>}<button onClick={add}>Save asset</button></Card>}
 <Card title="" right={<span><input style={{width:180,margin:0}} placeholder="Search..." value={q} onChange={e=>sq(e.target.value)}/> <select style={{width:120,margin:0}} value={t} onChange={e=>st(e.target.value)}>{['All','Bridge','Flyover','Dam','Tunnel','Road'].map(x=><option key={x}>{x}</option>)}</select></span>}>
 <table><thead><tr><th>Name</th><th>Type</th><th>Location</th><th>Status</th><th>Actions</th></tr></thead><tbody>
 {rows.map(a=><tr key={a.id}><td>{a.name}</td><td>{a.type}</td><td>{a.location}</td><td><Badge t={a.status}/></td><td>
 <Link to={'/assets/'+a.id}>View</Link> · <a href="#/assets" onClick={()=>{const n=prompt('Edit asset name',a.name);if(n&&n.trim())sl(list.map(x=>x.id==a.id?{...x,name:n.trim()}:x))}}>Edit</a> · <a href="#/assets" onClick={()=>sl(list.filter(x=>x.id!=a.id))}>Remove</a></td></tr>)}
 </tbody></table>{!rows.length&&<p>No assets found.</p>}</Card></>}
export function AssetDetail(){
 const {id}=useParams(),[list]=useStore('is_assets',assets),[insp]=useStore('is_insp',inspections),a=list.find(x=>x.id==id)
 if(!a)return <><h1>Asset not found</h1><Link to="/assets">Back</Link></>
 return <><h1>{a.name}</h1><Card title="Asset information"><div style={{height:120,borderRadius:8,background:'linear-gradient(135deg,#0b1f3a,#2563eb)',marginBottom:10}}/>
 <p>Type: {a.type}<br/>Location: {a.location}<br/>Status: <Badge t={a.status}/> Current severity: <Badge t={a.severity}/></p></Card>
 <Card title="Inspection history"><table><thead><tr><th>ID</th><th>Date</th><th>Defects</th><th>Severity</th></tr></thead><tbody>
 {insp.filter(i=>i.asset==a.name).map(i=><tr key={i.id}><td>{i.id}</td><td>{i.date}</td><td>{i.defects}</td><td><Badge t={i.severity}/></td></tr>)}</tbody></table></Card><Link to="/assets">← Back to assets</Link></>}
export function MapView(){
 const [list]=useStore('is_assets',assets),[sel,ss]=useState(null)
 return <><h1>Map View (sample map)</h1><Card title="Infrastructure locations" right={<span>{Object.keys(col).map(k=><span key={k} style={{marginLeft:10}}><span className="pin" style={{position:'static',display:'inline-block',verticalAlign:'middle',background:col[k],width:12,height:12}}/> {k}</span>)}</span>}>
 <div className="map">{list.map(a=><button key={a.id} className="pin" title={a.name} style={{left:a.x+'%',top:a.y+'%',background:col[a.severity]}} onClick={()=>ss(a)}/>)}</div></Card>
 {sel&&<Card title={sel.name}><p>{sel.type} · {sel.location}<br/>Severity: <Badge t={sel.severity}/> Status: <Badge t={sel.status}/></p><Link to={'/assets/'+sel.id}>View details</Link></Card>}</>}
