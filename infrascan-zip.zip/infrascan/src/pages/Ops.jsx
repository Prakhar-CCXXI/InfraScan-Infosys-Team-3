import {useState} from 'react'
import {Badge,Card,Stat,Field,Bars,useStore,downloadCSV,downloadJSON} from '../ui.jsx'
import {tasks,users,roles,inspections,assets} from '../data.js'
export function Maintenance(){
 const [list,sl]=useStore('is_tasks',tasks),[as]=useStore('is_assets',assets),[f,sf]=useState({asset:as[0]?.name||'',desc:'',priority:'Medium',due:''}),[e,se]=useState('')
 const add=()=>{if(!f.desc.trim()||!f.due)return se('Description and due date are required');sl([...list,{...f,id:Date.now(),status:'Pending'}]);sf({...f,desc:'',due:''});se('')}
 return <><h1>Maintenance Management</h1><Card title="Add task">
 <label>Asset<select value={f.asset} onChange={x=>sf({...f,asset:x.target.value})}>{as.map(a=><option key={a.id}>{a.name}</option>)}</select></label>
 <Field label="Task description" value={f.desc} onChange={x=>sf({...f,desc:x.target.value})}/>
 <label>Priority<select value={f.priority} onChange={x=>sf({...f,priority:x.target.value})}>{['High','Medium','Low'].map(p=><option key={p}>{p}</option>)}</select></label>
 <Field label="Due date" type="date" value={f.due} onChange={x=>sf({...f,due:x.target.value})}/>{e&&<div className="err">{e}</div>}<button onClick={add}>Add task</button></Card>
 <Card title="Tasks"><table><thead><tr><th>Asset</th><th>Task</th><th>Priority</th><th>Due</th><th>Status</th></tr></thead><tbody>
 {list.map(t=><tr key={t.id}><td>{t.asset}</td><td>{t.desc}</td><td><Badge t={t.priority}/></td><td>{t.due}</td><td>
 <select style={{margin:0}} value={t.status} onChange={x=>sl(list.map(y=>y.id==t.id?{...y,status:x.target.value}:y))}>{['Pending','In Progress','Done'].map(s=><option key={s}>{s}</option>)}</select></td></tr>)}</tbody></table></Card></>}
export function Reports(){
 const [list]=useStore('is_insp',inspections),c=s=>list.filter(i=>i.severity==s).length
 return <><div className="row"><h1>Inspection Report</h1><span className="noprint"><button onClick={()=>downloadCSV('infrascan-report.csv',list)}>Download CSV</button> <button className="ghost" onClick={()=>downloadJSON('infrascan-report.json',list)}>Download JSON</button> <button className="ghost" onClick={()=>window.print()}>Print / Save PDF</button></span></div>
 <div className="grid"><Stat label="Inspections" value={list.length}/><Stat label="Total defects" value={list.reduce((s,i)=>s+i.defects,0)}/><Stat label="High severity" value={c('High')}/></div>
 <Card title="Severity details"><table><thead><tr><th>ID</th><th>Asset</th><th>Date</th><th>Defects</th><th>Severity</th></tr></thead><tbody>
 {list.map(i=><tr key={i.id}><td>{i.id}</td><td>{i.asset}</td><td>{i.date}</td><td>{i.defects}</td><td><Badge t={i.severity}/></td></tr>)}</tbody></table></Card></>}
export function Analytics(){
 const [list]=useStore('is_insp',inspections),c=s=>list.filter(i=>i.severity==s).length
 return <><h1>Analytics Dashboard (sample data)</h1>
 <div className="grid"><Stat label="Assets monitored" value="4"/><Stat label="Inspections" value={list.length}/><Stat label="Avg defects / inspection" value={(list.reduce((s,i)=>s+i.defects,0)/list.length).toFixed(1)}/></div>
 <div className="grid"><Card title="Defect distribution"><Bars data={[['Cracks',18],['Spalling',9],['Corrosion',6],['Leakage',3]]}/></Card>
 <Card title="Severity distribution"><Bars color="#dc2626" data={[['High',c('High')],['Moderate',c('Moderate')],['Low',c('Low')]]}/></Card>
 <Card title="Inspection trend"><Bars color="#0b1f3a" data={[['Jun',4],['Jul',6],['Aug',5],['Sep',8],['Oct',10]]}/></Card></div></>}
export function Users(){
 const [list,sl]=useStore('is_users',users),[q,sq]=useState(''),[r,sr]=useState('All'),[f,sf]=useState({name:'',email:'',role:roles[0]}),[e,se]=useState('')
 const rows=list.filter(u=>(r=='All'||u.role==r)&&(u.name+u.email).toLowerCase().includes(q.toLowerCase()))
 const add=()=>{if(!f.name.trim()||!/^\S+@\S+\.\S+$/.test(f.email))return se('Valid name and email required');sl([...list,{...f,id:Date.now(),status:'Active'}]);sf({name:'',email:'',role:roles[0]});se('')}
 return <><h1>User Management</h1><Card title="Add user"><div className="row"><input placeholder="Name" value={f.name} onChange={x=>sf({...f,name:x.target.value})}/><input placeholder="Email" value={f.email} onChange={x=>sf({...f,email:x.target.value})}/>
 <select value={f.role} onChange={x=>sf({...f,role:x.target.value})}>{roles.map(x=><option key={x}>{x}</option>)}</select><button onClick={add}>Add User</button></div>{e&&<div className="err">{e}</div>}</Card>
 <Card title="" right={<span><input style={{width:180,margin:0}} placeholder="Search..." value={q} onChange={x=>sq(x.target.value)}/> <select style={{width:200,margin:0}} value={r} onChange={x=>sr(x.target.value)}>{['All',...roles].map(x=><option key={x}>{x}</option>)}</select></span>}>
 <table><thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Status</th></tr></thead><tbody>
 {rows.map(u=><tr key={u.id}><td>{u.name}</td><td>{u.email}</td><td>{u.role}</td><td><a href="#/users" onClick={()=>sl(list.map(x=>x.id==u.id?{...x,status:x.status=='Active'?'Inactive':'Active'}:x))}><Badge t={u.status}/></a></td></tr>)}</tbody></table></Card></>}
export function Profile(){
 const u=JSON.parse(localStorage.getItem('is_user')||'{}'),[f,sf]=useState({name:u.name||'',email:u.email||''}),[n,sn]=useStore('is_notif',{email:true,high:true,weekly:false}),[m,sm]=useState('')
 const save=()=>{if(!f.name.trim()||!/^\S+@\S+\.\S+$/.test(f.email))return sm('Enter a valid name and email');localStorage.setItem('is_user',JSON.stringify({...u,...f}));sm('Changes saved ✔')}
 return <><h1>Profile and Settings</h1><Card title={'Profile · '+(u.role||'')}><Field label="Name" value={f.name} onChange={x=>sf({...f,name:x.target.value})}/><Field label="Email" value={f.email} onChange={x=>sf({...f,email:x.target.value})}/>
 <button onClick={save}>Save Changes</button> {m&&<span>{m}</span>}</Card>
 <Card title="Notification preferences">{[['email','Email notifications'],['high','High-severity alerts'],['weekly','Weekly summary']].map(([k,l])=>
 <label key={k} style={{display:'block',marginBottom:8}}><input type="checkbox" style={{width:'auto'}} checked={n[k]} onChange={x=>sn({...n,[k]:x.target.checked})}/> {l}</label>)}</Card></>}

export function Notifications(){
 const defaults=[
  {id:1,level:'critical',title:'High-severity crack detected',detail:'Marina Bridge · 92% demo confidence · Immediate engineering review recommended.',time:'12 min ago',read:false},
  {id:2,level:'high',title:'Maintenance deadline approaching',detail:'Seal deck cracks is due in 3 days.',time:'1 hour ago',read:false},
  {id:3,level:'medium',title:'Inspection scheduled',detail:'Anna Flyover inspection scheduled for tomorrow.',time:'Yesterday',read:true}
 ]
 const [list,sl]=useStore('is_notifications',defaults),[filter,sf]=useState('All')
 const rows=list.filter(n=>filter=='All'||(filter=='Unread'?!n.read:n.read))
 return <><div className="row"><h1>Notifications and Alerts</h1><button className="ghost" onClick={()=>sl(list.map(n=>({...n,read:true})))}>Mark all read</button></div>
 <Card title="Alert center" right={<select value={filter} onChange={e=>sf(e.target.value)} style={{width:150,margin:0}}>{['All','Unread','Read'].map(x=><option key={x}>{x}</option>)}</select>}>
 {rows.map(n=><div key={n.id} className={'card notice '+n.level} style={{marginBottom:10,background:n.read?'#f8fafc':'#fff',cursor:'pointer'}} onClick={()=>sl(list.map(x=>x.id==n.id?{...x,read:true}:x))}>
 <div className="row"><b>{n.title}</b><span style={{fontSize:12,color:'#64748b'}}>{n.time}</span></div><p style={{margin:'6px 0'}}>{n.detail}</p>{!n.read&&<span className="b">Unread</span>}</div>)}
 {!rows.length&&<p>No notifications in this view.</p>}</Card></>
}

export function Models(){
 const [models,sm]=useStore('is_models',[
  {id:'crack-seg-v3',name:'Crack Segmentation',type:'Semantic segmentation',version:'v3.2',status:'Deployed',precision:'94.1%',recall:'91.8%',f1:'92.9%',updated:'2026-10-15'},
  {id:'damage-cls-v2',name:'Surface Damage Classifier',type:'Multi-class classification',version:'v2.7',status:'Deployed',precision:'89.5%',recall:'87.2%',f1:'88.3%',updated:'2026-09-28'},
  {id:'severity-v1',name:'Severity Assessment',type:'Rule-assisted ensemble',version:'v1.4',status:'Testing',precision:'86.0%',recall:'84.3%',f1:'85.1%',updated:'2026-10-01'}
 ])
 return <><h1>Model Management</h1><p className="b pending">Demo registry and metrics only. No live model inference or deployment is connected.</p>
 <div className="grid"><Card title="Registered models"><Stat label="Models" value={models.length}/></Card><Card title="Deployed"><Stat label="Deployed" value={models.filter(m=>m.status=='Deployed').length}/></Card><Card title="Status"><Stat label="Testing" value={models.filter(m=>m.status=='Testing').length}/></Card></div>
 <Card title="Model registry"><table><thead><tr><th>Model</th><th>Type</th><th>Version</th><th>Precision</th><th>Recall</th><th>F1</th><th>Status</th><th>Action</th></tr></thead><tbody>
 {models.map(m=><tr key={m.id}><td><b>{m.name}</b><br/><span style={{fontSize:11,color:'#64748b'}}>{m.updated}</span></td><td>{m.type}</td><td>{m.version}</td><td>{m.precision}</td><td>{m.recall}</td><td>{m.f1}</td><td><Badge t={m.status}/></td><td><button className="ghost" onClick={()=>sm(models.map(x=>x.id==m.id?{...x,status:x.status=='Deployed'?'Testing':'Deployed'}:x))}>{m.status=='Deployed'?'Move to Testing':'Deploy demo'}</button></td></tr>)}</tbody></table></Card></>
}

export function AuditLog(){
 const [list,sl]=useStore('is_audit',[
  {id:1,time:'2026-10-20 14:32',user:'Ravi Kumar',action:'Ran sample damage analysis',target:'INS-101'},
  {id:2,time:'2026-10-20 10:15',user:'Sneha Devi',action:'Updated maintenance task',target:'Task 2'},
  {id:3,time:'2026-10-19 16:48',user:'Meena S',action:'Changed user role',target:'Arun Raj'},
  {id:4,time:'2026-10-18 09:20',user:'Ravi Kumar',action:'Added infrastructure asset',target:'Marina Bridge'}
 ])
 return <><h1>Audit Logs</h1><Card title="Recent activity"><table><thead><tr><th>Time</th><th>User</th><th>Action</th><th>Target</th></tr></thead><tbody>
 {list.map(x=><tr key={x.id}><td>{x.time}</td><td>{x.user}</td><td>{x.action}</td><td>{x.target}</td></tr>)}</tbody></table>
 <button className="ghost" onClick={()=>sl([])}>Clear local demo log</button></Card></>
}
