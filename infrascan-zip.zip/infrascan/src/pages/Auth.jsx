import {useState} from 'react'
import {Link,useNavigate} from 'react-router-dom'
import {Field} from '../ui.jsx'
import {roles} from '../data.js'
const ok=e=>/^\S+@\S+\.\S+$/.test(e)
const Shell=({title,children})=><div className="auth"><div className="card"><h2 style={{margin:0}}>🏗 InfraScan</h2>
<p style={{color:'#64748b'}}>{title}</p>{children}<p style={{fontSize:11,color:'#94a3b8'}}>Demo only: simulated authentication, no real accounts.</p></div></div>
const save=u=>localStorage.setItem('is_user',JSON.stringify(u))
export function Login(){
 const [f,sf]=useState({email:'',password:''}),[e,se]=useState({}),nav=useNavigate()
 const go=ev=>{ev.preventDefault();const x={}
  if(!ok(f.email))x.email='Enter a valid email';if(f.password.length<6)x.password='Minimum 6 characters';se(x)
  if(Object.keys(x).length)return
  save({name:f.email.split('@')[0],email:f.email,role:localStorage.getItem('is_role')||roles[0]});nav('/dashboard')}
 return <Shell title="AI-Powered Infrastructure Inspection System"><form onSubmit={go}>
 <Field label="Email" value={f.email} err={e.email} onChange={v=>sf({...f,email:v.target.value})}/>
 <Field label="Password" type="password" value={f.password} err={e.password} onChange={v=>sf({...f,password:v.target.value})}/>
 <button style={{width:'100%'}}>Login</button></form>
 <p><a href="#/login" onClick={()=>alert('Demo: password reset not available')}>Forgot password?</a> · <Link to="/register">Register</Link></p></Shell>}
export function Register(){
 const [f,sf]=useState({name:'',email:'',password:''}),[e,se]=useState({}),nav=useNavigate()
 const go=ev=>{ev.preventDefault();const x={}
  if(f.name.trim().length<2)x.name='Name required';if(!ok(f.email))x.email='Enter a valid email';if(f.password.length<6)x.password='Minimum 6 characters';se(x)
  if(Object.keys(x).length)return
  save({name:f.name,email:f.email,role:roles[0]});nav('/roles')}
 return <Shell title="Create your account"><form onSubmit={go}>
 {['name','email','password'].map(k=><Field key={k} label={k[0].toUpperCase()+k.slice(1)} type={k=='password'?'password':'text'} value={f[k]} err={e[k]} onChange={v=>sf({...f,[k]:v.target.value})}/>)}
 <button style={{width:'100%'}}>Continue to role selection</button></form><p><Link to="/login">Back to login</Link></p></Shell>}
export function Roles(){
 const [r,sr]=useState(roles[0]),nav=useNavigate()
 const go=()=>{const u=JSON.parse(localStorage.getItem('is_user')||'{"name":"demo","email":"demo@infrascan.io"}')
  save({...u,role:r});localStorage.setItem('is_role',r);nav('/dashboard')}
 return <Shell title="Select your role">{roles.map(x=><div key={x} className={'role'+(x==r?' sel':'')} onClick={()=>sr(x)}>{x}</div>)}
 <button style={{width:'100%'}} onClick={go}>Continue</button></Shell>}
