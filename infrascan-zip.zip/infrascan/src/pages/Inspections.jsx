import {useState} from 'react'
import {Link,useNavigate} from 'react-router-dom'
import {Badge,Card,Stat,Field,useStore} from '../ui.jsx'
import {inspections,assets,defects} from '../data.js'
export function Dashboard(){
 const [list]=useStore('is_insp',inspections)
 return <><div className="row"><h1>Inspector Dashboard</h1><Link to="/inspections/new"><button>+ New Inspection</button></Link></div>
 <div className="grid"><Stat label="Total inspections" value={list.length}/><Stat label="Pending analysis" value={list.filter(i=>i.status=='Pending').length}/>
 <Stat label="Completed" value={list.filter(i=>i.status=='Completed').length}/><Stat label="High-severity issues" value={list.filter(i=>i.severity=='High').length}/></div>
 <Card title="Recent inspections"><table><thead><tr><th>ID</th><th>Asset</th><th>Date</th><th>Status</th><th>Severity</th></tr></thead>
 <tbody>{list.map(i=><tr key={i.id}><td>{i.id}</td><td>{i.asset}</td><td>{i.date}</td><td><Badge t={i.status}/></td><td><Badge t={i.severity}/></td></tr>)}</tbody></table></Card></>}
export function CreateInspection(){
 const [list]=useStore('is_assets',assets),nav=useNavigate()
 const [f,sf]=useState({asset:list[0]?.name||'',inspector:'',date:new Date().toISOString().slice(0,10),time:'09:00',priority:'Medium',team:'North Zone Inspection Team',description:''}),[e,se]=useState({})
 const next=()=>{const x={};if(!f.inspector.trim())x.inspector='Required';if(!f.date)x.date='Required';if(f.description.trim().length<5)x.description='Add a short description';se(x)
  if(Object.keys(x).length)return;localStorage.setItem('is_draft',JSON.stringify(f));nav('/inspections/upload')}
 const set=k=>v=>sf({...f,[k]:v.target.value})
 return <><h1>Create Inspection (Step 1 of 2)</h1><Card title="Inspection details">
 <label>Infrastructure asset<select value={f.asset} onChange={set('asset')}>{list.map(a=><option key={a.id}>{a.name}</option>)}</select></label>
 <Field label="Inspector name" value={f.inspector} err={e.inspector} onChange={set('inspector')}/>
 <Field label="Inspection date" type="date" value={f.date} err={e.date} onChange={set('date')}/>
 <Field label="Scheduled time" type="time" value={f.time} onChange={set('time')}/>
 <label>Priority<select value={f.priority} onChange={set('priority')}>{['High','Medium','Low'].map(x=><option key={x}>{x}</option>)}</select></label>
 <label>Assigned team<select value={f.team} onChange={set('team')}>{['North Zone Inspection Team','Metro Structures Team','Remote Asset Team'].map(x=><option key={x}>{x}</option>)}</select></label>
 <label>Description<textarea rows="3" value={f.description} onChange={set('description')}/></label>{e.description&&<div className="err">{e.description}</div>}
 <div className="row"><button className="ghost" onClick={()=>nav('/dashboard')}>Back</button><button onClick={next}>Next</button></div></Card></>}
export function Upload(){
 const [files,sfl]=useState([]),[on,son]=useState(false),[err,se]=useState(''),nav=useNavigate(),[list,sl]=useStore('is_insp',inspections)
 const add=fs=>sfl([...files,...[...fs].filter(f=>f.type.startsWith('image/')).map(f=>({name:f.name,url:URL.createObjectURL(f)}))])
 const run=()=>{if(!files.length)return se('Upload at least one image');const d=JSON.parse(localStorage.getItem('is_draft')||'{}')
  sl([{id:'INS-'+(100+list.length+1),asset:d.asset||'Marina Bridge',date:d.date||'',inspector:d.inspector||'Demo',status:'Completed',severity:'High',defects:3,images:files.length},...list]);nav('/inspections/results')}
 return <><h1>Upload Images (Step 2 of 2)</h1><Card title={`Images uploaded: ${files.length}`}>
 <div className={'drop'+(on?' on':'')} onDragOver={e=>{e.preventDefault();son(true)}} onDragLeave={()=>son(false)} onDrop={e=>{e.preventDefault();son(false);add(e.dataTransfer.files)}}>
 <p>Drag and drop images here</p><label className="b" style={{cursor:'pointer',background:'#2563eb',color:'#fff'}}>Browse files<input type="file" accept="image/*" multiple hidden onChange={e=>add(e.target.files)}/></label></div>
 <div className="thumbs">{files.map((f,i)=><div key={i}><img src={f.url} alt={f.name}/><button className="red" onClick={()=>sfl(files.filter((_,j)=>j!=i))}>×</button></div>)}</div>
 {err&&<div className="err">{err}</div>}<div className="row" style={{marginTop:14}}><button className="ghost" onClick={()=>nav('/inspections/new')}>Back</button><button onClick={run}>Run sample analysis</button></div></Card></>}
export function Results(){
 const [m,sm]=useState('original');const crack='40,30 120,90 160,150 250,190 340,230'
 const boxes=<g fill="none" stroke="#ef4444" strokeWidth="2"><rect x="100" y="70" width="80" height="100"/><rect x="230" y="170" width="120" height="70" stroke="#f59e0b"/></g>
 return <><h1>AI Analysis Results</h1><p className="b pending">Sample visualization with static demo data. No AI model is running.</p>
 <Card title="Visualization" right={<span>{['original','detection','segmentation','overlay','heatmap'].map(x=><button key={x} className={x==m?'':'ghost'} style={{marginLeft:4}} onClick={()=>sm(x)}>{x}</button>)}</span>}>
 <svg viewBox="0 0 400 260" width="100%" style={{maxWidth:640,borderRadius:8}}><defs><radialGradient id="h"><stop offset="0" stopColor="#ef4444" stopOpacity=".8"/><stop offset="1" stopColor="#facc15" stopOpacity="0"/></radialGradient></defs>
 <rect width="400" height="260" fill={m=='segmentation'?'#0f172a':'#94a3b8'}/>
 {m=='heatmap'?[[120,90],[160,150],[250,190]].map(([x,y])=><circle key={x} cx={x} cy={y} r="55" fill="url(#h)"/>):
 <polyline points={crack} fill="none" stroke={m=='segmentation'?'#22d3ee':m=='overlay'?'#38bdf8':'#334155'} strokeWidth={m=='segmentation'||m=='overlay'?8:3} strokeOpacity={m=='overlay'?.7:1}/>}
 {(m=='detection'||m=='overlay')&&boxes}</svg></Card>
 <Card title="Defect details"><table><thead><tr><th>Defect</th><th>Severity</th><th>Confidence</th><th>Size</th></tr></thead>
 <tbody>{defects.map(d=><tr key={d[0]}><td>{d[0]}</td><td><Badge t={d[1]}/></td><td>{d[2]}</td><td>{d[3]}</td></tr>)}</tbody></table></Card>
 <div className="grid">
  <Card title="Preprocessing and segmentation"><p><b>Original:</b> 4000 x 3000 px</p><p><b>Demo preprocessing:</b> resize, contrast normalization, noise reduction</p><p><b>Segmentation mask:</b> 12.4% crack pixels</p></Card>
  <Card title="Crack classification"><p><b>Primary class:</b> Longitudinal crack</p><p><b>Surface damage:</b> Spalling + surface corrosion</p><p><b>Orientation:</b> Horizontal / 16 degrees</p></Card>
  <Card title="Measurements"><p><b>Length:</b> 12.0 cm</p><p><b>Width:</b> 4.8 mm</p><p><b>Area:</b> 48 cm²</p><p><b>Calibration:</b> Not available</p></Card>
 </div>
 <div className="grid">
  <Card title="Damage severity assessment"><p><b>Overall severity:</b> <Badge t="High"/></p><p><b>Demo score:</b> 78 / 100</p><p><b>Recommended response:</b> Inspect within 7 days and plan repair.</p></Card>
  <Card title="Explainable AI"><p>High weight: crack continuity and width</p><div style={{height:12,borderRadius:6,background:'#fee2e2',overflow:'hidden'}}><div style={{width:'92%',height:'100%',background:'#dc2626'}}/></div><p>Crack continuity 92% · Width 84% · Location 76%</p><p style={{fontSize:12,color:'#64748b'}}>Demo explanation; not from a live model.</p></Card>
 </div></>}

export function InspectionHistory(){
 const [list]=useStore('is_insp',inspections),[q,sq]=useState(''),[asset,sa]=useState('All')
 const names=['All',...new Set(list.map(i=>i.asset))]
 const rows=list.filter(i=>(asset=='All'||i.asset==asset)&&(i.id+i.asset+i.inspector).toLowerCase().includes(q.toLowerCase()))
 return <><div className="row"><h1>Inspection History</h1><Link to="/inspections/new"><button>+ New Inspection</button></Link></div>
 <Card title="Filters" right={<span><input placeholder="Search inspections" value={q} onChange={e=>sq(e.target.value)} style={{width:180,margin:0}}/> <select value={asset} onChange={e=>sa(e.target.value)} style={{width:180,margin:0}}>{names.map(x=><option key={x}>{x}</option>)}</select></span>}>
 <table><thead><tr><th>Inspection</th><th>Asset</th><th>Inspector</th><th>Date</th><th>Status</th><th>Severity</th><th></th></tr></thead><tbody>
 {rows.map(i=><tr key={i.id}><td>{i.id}</td><td>{i.asset}</td><td>{i.inspector}</td><td>{i.date}</td><td><Badge t={i.status}/></td><td><Badge t={i.severity}/></td><td><Link to="/inspections/results">View analysis</Link></td></tr>)}</tbody></table>
 {!rows.length&&<p>No inspections match the filters.</p>}</Card></>
}

export function DamageProgression(){
 const [metric,sm]=useState('Crack length'),[asset,sa]=useState('Marina Bridge')
 const series={ 'Marina Bridge':[32,38,47,52], 'Anna Flyover':[18,21,24,29] }
 const values=series[asset]||series['Marina Bridge']
 return <><h1>Damage Progression</h1><p className="b pending">Demo comparison - requires comparable viewpoints and calibrated scale.</p>
 <Card title="Historical comparison" right={<span><select value={asset} onChange={e=>sa(e.target.value)} style={{width:180,margin:0}}><option>Marina Bridge</option><option>Anna Flyover</option></select> <select value={metric} onChange={e=>sm(e.target.value)} style={{width:160,margin:0}}><option>Crack length</option><option>Crack width</option><option>Damage area</option></select></span>}>
 <div className="grid"><div><h3>Previous inspection</h3><div className="progress-image">Sep 02</div></div><div><h3>Current inspection</h3><div className="progress-image current">Oct 20</div></div></div>
 <table><thead><tr><th>Inspection date</th><th>{metric} (pixels*)</th><th>Visible change</th></tr></thead><tbody>
 {['Sep 02','Sep 28','Oct 10','Oct 20'].map((d,i)=><tr key={d}><td>{d}</td><td>{values[i]}</td><td>{i?'+'+(values[i]-values[i-1])+' from previous':'Baseline'}</td></tr>)}</tbody></table>
 <p style={{fontSize:12,color:'#64748b'}}>*Physical units require camera calibration. Trend values are sample data.</p></Card></>
}
