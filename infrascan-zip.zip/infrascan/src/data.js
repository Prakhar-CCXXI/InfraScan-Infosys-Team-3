export const assets=[
{id:'A1',name:'Marina Bridge',type:'Bridge',location:'Chennai, Marina',status:'Active',severity:'High',x:70,y:30},
{id:'A2',name:'Anna Flyover',type:'Flyover',location:'Anna Nagar',status:'Active',severity:'Moderate',x:35,y:55},
{id:'A3',name:'Adyar Dam',type:'Dam',location:'Adyar',status:'Under Repair',severity:'Low',x:55,y:75},
{id:'A4',name:'Central Tunnel',type:'Tunnel',location:'Egmore',status:'Active',severity:'Low',x:20,y:25}]
export const inspections=[
{id:'INS-101',asset:'Marina Bridge',date:'2026-10-20',inspector:'R. Kumar',status:'Completed',severity:'High',defects:5,images:8},
{id:'INS-102',asset:'Anna Flyover',date:'2026-10-18',inspector:'S. Devi',status:'Pending',severity:'Moderate',defects:2,images:4},
{id:'INS-103',asset:'Adyar Dam',date:'2026-10-10',inspector:'R. Kumar',status:'Completed',severity:'Low',defects:1,images:6},
{id:'INS-104',asset:'Marina Bridge',date:'2026-09-02',inspector:'A. Raj',status:'Completed',severity:'Moderate',defects:3,images:5}]
export const tasks=[
{id:1,asset:'Marina Bridge',desc:'Seal deck cracks',priority:'High',due:'2026-11-05',status:'Pending'},
{id:2,asset:'Anna Flyover',desc:'Repaint expansion joints',priority:'Medium',due:'2026-11-20',status:'In Progress'},
{id:3,asset:'Adyar Dam',desc:'Spillway cleaning',priority:'Low',due:'2026-10-01',status:'Done'}]
export const users=[
{id:1,name:'Ravi Kumar',email:'ravi@infrascan.io',role:'Infrastructure Inspector',status:'Active'},
{id:2,name:'Sneha Devi',email:'sneha@infrascan.io',role:'Civil Engineer',status:'Active'},
{id:3,name:'Arun Raj',email:'arun@infrascan.io',role:'Maintenance Engineer',status:'Inactive'},
{id:4,name:'Meena S',email:'meena@infrascan.io',role:'Administrator',status:'Active'}]
export const roles=['Infrastructure Inspector','Civil Engineer','Maintenance Engineer','Infrastructure Manager','Administrator']
export const defects=[['Longitudinal crack','High','92%','12 cm'],['Spalling','Moderate','85%','8 cm'],['Surface corrosion','Low','78%','4 cm']]
